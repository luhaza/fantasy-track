package fantasytrackspringboot.fantasytrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FantasyTrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(FantasyTrackApplication.class, args);
	}

}
