package fantasytrackspringboot.fantasytrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FantasyTrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
